import { Component, OnInit } from '@angular/core';
import { UserSerService } from '../user-ser.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-posts',
  templateUrl: './user-posts.component.html',
  styleUrls: ['./user-posts.component.scss']
})
export class UserPostsComponent implements OnInit {

  public postt;
  constructor(private userSer:UserSerService,private route:Router) { }

  ngOnInit() {
    this.userSer.postPage().subscribe((res : any[])=>{
      this.postt=res;
      this.userSer.postData=this.postt;
   }); }
  }

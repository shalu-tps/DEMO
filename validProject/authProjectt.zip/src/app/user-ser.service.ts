import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

import { Router } from '@angular/router';
// import { IPosts } from 'src/app/emp';

@Injectable({
  providedIn: 'root'
})
export class UserSerService {

  public userData;
  public idDet;
 public apiUrl:string='https://jsonplaceholder.typicode.com/posts';

  constructor(private http:HttpClient,private route:Router) { }
  

loginData()
{
  return this.http.get('https://jsonplaceholder.typicode.com/users');
}
postPage()
{
  return this.http.get('https://jsonplaceholder.typicode.com/posts');
}
comments(id)
{
  return this.http.get('https://jsonplaceholder.typicode.com/posts');

}
public getComment(id: number){
  return this.http.get(`${this.apiUrl}/${id}/comments`);
 }
 public postDet(id: number){
  return this.http.get(`${this.apiUrl}/${id}`);
 }

 sendToken(value: string) {
  localStorage.setItem("userid", JSON.stringify(value))
 }
getToken() {
  return localStorage.getItem("userid")
}
isLoggednIn() {
  
  return this.getToken() !== null;

}
logout() {
  localStorage.removeItem("userid");
  this.route.navigate(["loginPage"]);
}

getById()
{
  const id=localStorage.getItem("userid");
  return this.http.get(`https://jsonplaceholder.typicode.com/users/`+id);
}
}
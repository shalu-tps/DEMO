export interface Details{
    id:string;
    username:string;
    email:string
}
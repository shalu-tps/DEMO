import { Component, OnInit } from '@angular/core';
import { UserSerService } from '../user-ser.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-post-page',
  // templateUrl: './post-page.component.html',
  template:`
  <h1>Posts</h1>
  <button [routerLink]="['/dashboard']" >Dashboard</button>
  <ul *ngFor="let ps of postt">
   <li> USERId ::{{ps.userId}}</li>
   <li>Id ::{{ps.id}}</li>
   <li> Title ::{{ps.title}}</li>
   <li>Body ::{{ps.body}}</li>
   <button (click)="onSelect(ps)">View Comments</button>
  </ul>
  
  `,

  styleUrls: ['./post-page.component.scss']
})
export class PostPageComponent implements OnInit {

  public postt=[];
  public user;
  public arr=[];
  public data=[];
  public i;

  constructor(private userSer:UserSerService,private router:Router) { 
   this.userSer.postPage();
   
  }

  ngOnInit() {
    this.userSer.postPage().subscribe((res : any[])=>{
      this.postt=res;
   }); 
  }

  onSelect(ps){
    this.router.navigate(['/postPage',ps.id]);
  //  this.i=this.userSer.getComment(ps.id).subscribe((res:any[])=>{
  //    this.data=res;
  //  }); 
  //  console.log(this.i);

  }
     
  }

